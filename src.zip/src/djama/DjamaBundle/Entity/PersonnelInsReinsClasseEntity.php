<?php

namespace djama\DjamaBundle\Entity;

/**
 * Description of PersonnelInsReinsClasseEntity
 *
 * @author Djama
 */
class PersonnelInsReinsClasseEntity {
    //put your code here
}
