<?php

namespace djama\DjamaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class djamaDjamaBundle extends Bundle
{
}
